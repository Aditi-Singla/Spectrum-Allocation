#! /bin/bash

# read infile outfile
./output $1 $2